#======================================================================
#     for only-short-term-debt model
#======================================================================

import bench_decision # Solve the problem
import bench_simulation # Simulate the model
import os

#======================================================================

import time
st_time = time.time()

beta = 0.96
alpha = 0.65  # capital share in production function
delta = 0.025  # depreciation of capital
lambd = 0.05  # fraction of repayment for long-term bond
tau = 0.2  # corporate income tax rate
epsilon = 0.01 # exogenous death rate
theta_k = 0.5 # capital adjustment cost parameter
theta_bs = 0.12 # short term bond issuance cost
theta_bl = 1.17 # long-term bond issuance cost
chi = 0.8  # recovery rate
mul = 1.0  # weight for long-term debt
phi = 1.605 # fixed cost of operating
rbar = 0.01  # to scale interest rate
rho_r = 0.5  # persistence in interest rate
eta_r = 0.08  # st dev of interest rate
rho_z = 0.9  # persistence in productivity
eta_z = 0.03  # st dev of productivity
nz = 11  # number of points in z grid
nr = 11 # number of points in r grid
nk = 100 # number of points in k grid
nB = 100  # number of points in Bgrid (total debt)
nf = 1  # number of points in fgrid (fraction of long-term debt)
tol = 5e-5  # error tolerance in iteration
maxit = 1500

print("Solving the problem...")

se = bench_decision.Maturity_Economy(beta = beta,      # discount factor
                 alpha = alpha,  # capital share in production function
                 delta = delta,  # depreciation of capital
                 lambd = lambd,  # fraction of repayment for long-term bond
                 tau = tau,  # corporate income tax rate
                 epsilon = epsilon,  # exogenous death rate
                 theta_k = theta_k,  # capital adjustment cost parameter
                 theta_bs = theta_bs,  # short term bond issuance cost
                 theta_bl = theta_bl,  # long-term bond issuance cost
                 chi = chi,  # recovery rate
                 mul = mul,  # weight for long-term debt
                 phi = phi,  # fixed cost of operating
                 rbar = rbar,  # to scale interest rate
                 rho_r = rho_r,  # persistence in interest rate
                 eta_r = eta_r,  # st dev of interest rate
                 rho_z = rho_z,  # persistence in productivity
                 eta_z = eta_z,  # st dev of productivity
                 nz = nz,  # number of points in z grid
                 nr = nr,  # number of points in r grid
                 nk = nk,  # number of points in k grid
                 nB = nB,  # number of points in Bgrid (total debt)
                 nf = nf,  # number of points in fgrud (fraction of long-term debt)
                 tol = tol,  # error tolerance in iteration
                 maxit = maxit)


print("Simulating the model...")

sim = bench_simulation.Maturity_Economy_Simulation(rbar = rbar,
                 rho_r = rho_r,  # persistence in interest rate
                 eta_r = eta_r,  # st dev of interest rate
                 rho_z = rho_z,  # persistence in productivity
                 eta_z = eta_z,  # st dev of productivity
                 nz = nz,  # number of points in z grid
                 nr = nr,
                 theta_k = theta_k,
                 theta_bs = theta_bs,  # short term bond issuance cost
                 theta_bl = theta_bl,  # long-term bond issuance cost
                 phi = phi,
                 beta = beta,
                 delta = delta,
                 alpha = alpha,
                 epsilon = epsilon)


ed_time = time.time()
print("Total Running time:")
print(ed_time - st_time)
