
import os, sys, json

def check_load_data(path):
    if os.path.exists(path):
        data = json.load(open(path,'r'))
        return data
    else:
        return None

def save_data(data, path):
    json.dump(data, open(path,'w'))


if __name__ == '__main__':
    def compute():
        a = []
        return a
    data = check_load_data('res.json')
    if data == None:
        data = compute()
        save_data(data, 'res.json')

